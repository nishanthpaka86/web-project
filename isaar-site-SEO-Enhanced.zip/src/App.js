import  { useState, useEffect } from "react";
import Navbar from './Components/Navbar';
import Hero from './Components/Hero';
import About from './Components/About';
import Services from './Components/Services';
import Contact from './Components/Contact';
import Footer from './Components/Footer';
import Career from "./Components/Careers";
import './index.css'; 

function App() {
  const [currentSection, setCurrentSection] = useState("home");

  useEffect(() => {
    document.title = "INDIAN SCIENTIFIC AREOSPACE AND ROBOTICS";
  }, []);

  return (
    <>
      <Navbar setCurrentSection={setCurrentSection} />
      {currentSection === "home" && <Hero setCurrentSection={setCurrentSection} />}
      {currentSection === "about" && <About />}
      {currentSection === "services" && <Services />}
      {currentSection === "contact" && <Contact />}
      {currentSection === "footer" && <Footer />}
      {currentSection === "careers" && <Career/>}
      <Footer/>
    </>
  );
}

export default App;