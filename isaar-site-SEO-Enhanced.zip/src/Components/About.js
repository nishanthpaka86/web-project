import './About.css';
import journeyImage from  '../s1.png'; // Update with your image path
import valuesImage from  '../s2.png'; // Update with your image path
import mission from  '../s3.png'; // Update with your image path

const About = () => (
  <section id="about" className="about">
    <h2>ABOUT ISAR</h2>
    <p className="intro">
      ISSAR is a premier institute providing innovative research and consultancy solutions to empower industries and academia. 
      We specialize in bridging the gap between research and practical applications.
    </p>

    <div className="about-images">
      <div className="about-image-container">
        <img src={mission} alt="Our mission and vision" />
        <div className="image-text">
          <h3>our mission and vision</h3>
          <p>
            At INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS, we are dedicated to providing top-tier drone technology training and theoretical knowledge to aspiring individuals. Our goal is to empower students, parents, and undergraduates with the skills needed to excel in the field of drones.
          </p>
        </div>
      </div>
      <div className="about-image-container">
        <img src={journeyImage} alt="Our Journey" />
        <div className="image-text">
          <h3>Our Journey</h3>
          <p>
            Established with a passion for innovation and education, INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS has been at the forefront of drone technology training. 
            Our commitment to excellence has driven us to create a platform that nurtures talent and fosters growth.
          </p>
        </div>
      </div>
      
      <div className="about-image-container">
        <img src={valuesImage} alt="Our Core Values" />
        <div className="image-text">
          <h3>Our Core Values</h3>
          <p>
            At INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS, we uphold integrity, innovation, and excellence in all aspects of our training programs. 
            We are committed to providing a nurturing environment that fosters learning and growth.
          </p>
        </div>
      </div>
    </div>
  </section> 
);

export default About;
