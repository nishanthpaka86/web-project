import './Footer.css';
import { FaFacebook, FaInstagram, FaLinkedin } from 'react-icons/fa';

const Footer = () => (
  <footer className="footer">
    <div className='footer-text'>
      <p>&copy; {new Date().getFullYear()} www.isaar.in</p>
    <div className='footer-icons'>
      <a href='https://www.instagram.com/_isar_25?igsh=MTR6OWFrd2V6dWs5Zw==' target="_blank" rel="noopener noreferrer">
        <FaInstagram size={20} style={{ marginRight: '8px' }} /> 
      </a>
      <a href='https://www.linkedin.com/company/indian-scientific-aerospace-and-robotics/' target="_blank" rel="noopener noreferrer">
        <FaLinkedin size={20} style={{ marginRight: '8px' }} /> 
      </a>
      <a href='https://www.facebook.com/share/16n143NgEy/' target="_blank" rel="noopener noreferrer">
        <FaFacebook size={20} style={{ marginRight: '8px' }} />
      </a>
    </div>
    </div>
  </footer>
);

export default Footer;
