import React from "react";
import Advanced from  '../o1.png'; // Update with your image path
import Young from  '../o2.png'; // Update with your image path
import Junior from  '../o3.png'; 
import senior from  '../o4.png'; 
import commingsoon from'../s5.png';
import './Services.css';

const Services = () => (
   <section id="services" className="services">
    <h2>DRONE COURSE</h2>
    <p className="starting">
      ISSAR is a premier institute providing innovative research and consultancy solutions to empower industries and academia. 
      We specialize in bridging the gap between research and practical applications.
    </p>

    <div className="about-grid">
      <div className="card">
        <img src={Advanced} alt="Young Learners (Kids)" />
        <div className="text">
          <h3>Young Learners (Kids)</h3>
          <p>
           Fun and safe drone introduction! Kids learn basic flight and safety through hands-on activities.
           </p>
        </div>
      </div>
      <div className="card">
        <img src={Young} alt="Junior High Drone Training (Grades 8-10)" />
        <div className="text">
          <h3>Junior High Drone Training (Grades 8-10)</h3>
          <p>
            Unlock the secrets of drone technology! Explore how drones capture amazing data, solve real-world problems, and learn to pilot with confidence.
          </p>
        </div>
      </div>
      
      <div className="card">
        <img src={Junior} alt="Senior High Drone Training (Grades 11-12)" />
        <div className="text">
          <h3>Senior High Drone Training (Grades 11-12)</h3>
          <p>
            Master the art of drone operations! From technical flight skills to real-world applications, this course equips you with the knowledge and abilities needed to succeed in the drone field.
          </p>
        </div>
       </div> 
        <div className="advanced">
        <img src={senior} alt="Advanced Drone Training(Undergraduate)" />
        <div className="text">
          <h3>Advanced Drone Training(Undergraduate)</h3>
          <p>
           Professional drone training! Master advanced technology and industry-specific applications.
          </p>
        </div>
<div className="comingsoon-section">
  <div className="image-overlay-container">
    <img src={commingsoon} alt="Coming Soon" className="full-width-img" />
    <h1 className="coming-soon-overlay">COMING SOON</h1>
  </div>
</div>
</div>

</div>
  </section>
);

export default Services;

  


