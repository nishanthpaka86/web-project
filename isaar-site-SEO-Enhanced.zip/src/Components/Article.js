
import React
import { Helmet } from "react-helmet";

<Helmet>
  <title>Indian Scientific Aerospace and Robotics Institute</title>
  <meta name="description" content="Explore ISAR - Advancing space science, aerospace research, and robotic innovation in India." />
  <link rel="canonical" href="https://www.isaar.in/article" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="Indian Scientific Aerospace and Robotics Institute" />
  <meta property="og:description" content="Explore ISAR - Advancing space science, aerospace research, and robotic innovation in India." />
  <meta property="og:url" content="https://www.isaar.in/article" />
  <meta property="og:site_name" content="ISAR" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="Indian Scientific Aerospace and Robotics Institute" />
  <meta name="twitter:description" content="Explore ISAR - Advancing space science, aerospace research, and robotic innovation in India." />
  <script type="application/ld+json">
    {`
      {
        "@context": "https://schema.org",
        "@type": "Article",
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": "https://www.isaar.in/article"
        },
        "headline": "Indian Scientific Aerospace and Robotics Institute",
        "description": "Explore ISAR - Advancing space science, aerospace research, and robotic innovation in India.",
        "publisher": {
          "@type": "Organization",
          "name": "ISAR",
          "logo": {
            "@type": "ImageObject",
            "url": "https://www.isaar.in/logo.png"
          }
        },
        "author": {
          "@type": "Organization",
          "name": "ISAR"
        }
      }
    `}
  </script>
</Helmet>
 from "react";
import { Helmet } from "react-helmet";

const Article = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Indian Scientific Aerospace and Robotics Institute",
    "description": "Explore the Indian Scientific Aerospace and Robotics Institute (ISAR) — where technology meets innovation.",
    "author": {
      "@type": "Organization",
      "name": "ISAR"
    },
    "publisher": {
      "@type": "Organization",
      "name": "ISAR",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.isaar.in/logo.png"
      }
    },
    "datePublished": "2025-06-17",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://www.isaar.in/article"
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto text-left">
      <Helmet>
        <title>Indian Scientific Aerospace and Robotics Institute</title>
        <meta name="description" content="Explore the Indian Scientific Aerospace and Robotics Institute (ISAR) — where technology meets innovation. Learn about ISAR's mission, research, and future goals." />
        <meta name="keywords" content="ISAR, Aerospace, Robotics, Indian Research Institute, Technology, Innovation, Artificial Intelligence, Space Research" />
        <link rel="canonical" href="https://www.isaar.in/article" />

        {/* Open Graph */}
        <meta property="og:title" content="Indian Scientific Aerospace and Robotics Institute" />
        <meta property="og:description" content="Explore how ISAR is leading innovation in aerospace and robotics in India." />
        <meta property="og:image" content="https://www.isaar.in/og-image.jpg" />
        <meta property="og:url" content="https://www.isaar.in/article" />
        <meta property="og:type" content="article" />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Indian Scientific Aerospace and Robotics Institute" />
        <meta name="twitter:description" content="Explore how ISAR is leading innovation in aerospace and robotics in India." />
        <meta name="twitter:image" content="https://www.isaar.in/og-image.jpg" />

        {/* JSON-LD Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(jsonLd)}
        </script>
      </Helmet>

      <h1><strong>Indian Scientific Aerospace and Robotics Institute</strong></h1>
      <p><em>Created with <a href="https://www.aiprm.com/prompts/seo/writing/1784224785543462912/">AIPRM Prompt</a></em></p>
      <p><em>For better results, try <a href="https://chatgpt.com/g/g-xMTYfDbb4-article-writer-gpt">Article Writer GPT</a></em></p>

      <h2><strong>1. Introduction to ISAR</strong></h2>
      <p>Indian Scientific Aerospace and Robotics Institute (ISAR) is a beacon of innovation in India’s scientific and technological frontier...</p>

      {/* Content continues... */}

      <p><em>Please don’t forget to leave a review.</em></p>
      <p><em>Explore more by joining me on <a href="https://www.patreon.com/jumma/shop/lifetime-access-to-my-exclusive-prompts-3213">Patreon</a></em></p>
    </div>
  );
};

export default Article;
