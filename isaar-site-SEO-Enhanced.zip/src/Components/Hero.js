import { useState } from 'react';
import { Helmet } from 'react-helmet';
import './Hero.css';
import Spline from '@splinetool/react-spline';

// Import gallery images and video
import gallery1 from '../Screenshot 2025-05-27 124214.png';
import gallery2 from '../Screenshot 2025-05-27 124242.png';
import gallery3 from '../Screenshot 2025-05-27 124300.png';
import gallery4 from '../Screenshot 2025-05-27 124339.png';
import gallery5 from '../Screenshot 2025-05-27 124339.png';
import gallery6 from '../Screenshot 2025-05-27 124356.png';
import gallery7 from '../Screenshot 2025-05-27 124412.png';
//import video from '../assets/video.mp4';

const Hero = ({ setCurrentSection }) => {
  const handleContactClick = () => setCurrentSection("contact");
  const handleServicesClick = () => setCurrentSection("services");

  const galleryItems = [
    { type: 'image', src: gallery1 },
    { type: 'image', src: gallery2 },
    { type: 'image', src: gallery3 },
    { type: 'image', src: gallery4 },
    { type: 'image', src: gallery5 },
    { type: 'image', src: gallery6 },
    { type: 'image', src: gallery7 },
   // { type: 'video', src: video }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? galleryItems.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === galleryItems.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <>
      <section id="hero" className="hero">
          <Helmet>
        <title>INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</title>
        <meta
          name="description"
          content="Join ISAR – the top drone training center in India offering expert-led courses in drone technology, aerospace, and robotics. Enroll in Chennai’s leading drone institute today. drone training. drone training . "
        />
        <meta
          name="keywords"
          content="best drone training center in Chennai, drone training in India, drone pilot certification, aerospace training, ISAR"
        />

        {/* Open Graph / Facebook */}
        <meta property="og:title" content="ISAR | Best Drone Training in India" />
        <meta
          property="og:description"
          content="Learn drone flying, aerial survey, and robotics from certified experts at ISAR – Indian Scientific Aerospace and Robotics."
        />
        <meta property="og:image" content="/isar-preview.png" />
        <meta property="og:url" content="https://www.isar.in" />
        <meta property="og:type" content="website" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="ISAR | Drone Training Institute in India" />
        <meta name="twitter:description" content="Expert drone pilot training in Chennai at ISAR. Join India's top aerospace and robotics institute." />
        <meta name="twitter:image" content="/isar-preview.png" />

        {/* JSON-LD Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "ISAR - Indian Scientific Aerospace and Robotics",
            "image": "https://www.isar.in/isar-preview.png",
            "url": "https://www.isaar.in",
            "telephone": "+91-6374720788",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "339/2 at kurunji Nagar Valayapatti, Mohanur , Namakkal District, Tamil Nadu",
              "addressLocality": "Chennai",
              "addressRegion": "Tamil Nadu",
              "postalCode": "637020",
              "addressCountry": "IN"
            },
            "description": "Top drone training center in India, offering hands-on certification in drone tech, robotics, and aerospace.",
            "sameAs": ["https://www.instagram.com/_isar_25"]
          })}
        </script>
      </Helmet>
          <div className="hero-animation">
          <Spline className='spline' scene="https://prod.spline.design/9TLmRe8so0bDROmV/scene.splinecode" />
         <div className="hero-content">
          <h1>Welcome to ISAR</h1>
          <h3>Explore the Future of Drone Technology</h3>
          </div>
          <div className="contact-button-wrapper">
            <button className="btn" onClick={handleServicesClick}>
              Explore Our Services
            </button>
          </div>
          <p className="hero-description">
            We specialize in drone research, pilot training, aerial surveys, and industrial solutions.
            Discover how our technology is revolutionizing industries.
          </p>
        </div>
       
      </section>

      
      {/* Gallery Section */}
      <section className="gallery-section">
        <h1 className="gallery-title">Gallery</h1>
        <div className="gallery-wrapper">
          <button className="gallery-nav left" onClick={handlePrev}>❮</button>
          <div className="gallery-display">
            {galleryItems[currentIndex].type === 'image' ? (
              <img src={galleryItems[currentIndex].src} alt={`Gallery ${currentIndex}`} />
            ) : (
              <video controls>
                <source src={galleryItems[currentIndex].src} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            )}
          </div>
          <button className="gallery-nav right" onClick={handleNext}>❯</button>
        </div>
      </section>
      <section className="contact-section">
        <div className="contact-container">
          <div className="contact-left">
            <h1>Get in Touch</h1>
          </div>
          <div className="contact-right">
            <h3>Visit Us</h3>
            <p>Reach Out to Us Today</p>
            <a href="https://www.instagram.com/_isar_25?igsh=MTR6OWFrd2V6dWs5Zw==">Subscribe</a>
            <p>Connect</p>
          </div>
        </div>
        <div className="contact-button-wrapper">
          <button className="contact-btn" onClick={handleContactClick}>
            Contact Us
          </button>
        </div>
      </section>
    </>
  );
};

export default Hero;
