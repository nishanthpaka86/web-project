import  { useState } from "react";
import './Navbar.css';
import logo from '../logo1.png'; // Adjust path as needed

function Navbar({ setCurrentSection }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen(prev => !prev);

  const handleNavClick = (section) => {
    setCurrentSection(section);
    setMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="logo-container">
        <img src={logo} alt="ISAR Logo" className="logo-image" />
        <h1 className="logo">INDIAN SCIENTIFIC AEROSPACE AND ROBOTICS</h1>
      </div>

      <button className="menu-toggle" onClick={toggleMenu}>☰</button>

      <ul className={`nav-links ${menuOpen ? "active" : ""}`}>
        <li><button onClick={() => handleNavClick("home")}>Home</button></li>
        <li><button onClick={() => handleNavClick("about")}>About</button></li>
        <li><button onClick={() => handleNavClick("services")}>Services</button></li>
        <li><button onClick={() => handleNavClick("careers")}>Career</button></li> {/* New Career option */}
        <li><button onClick={() => handleNavClick("contact")}>Contact</button></li>
      </ul>
    </nav>
  );
}

export default Navbar;
